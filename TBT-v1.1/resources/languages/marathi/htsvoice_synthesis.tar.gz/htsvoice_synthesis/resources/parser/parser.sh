 
 perl ./bin/il_parser_hts_marathi.pl अर्थात 